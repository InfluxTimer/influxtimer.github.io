Simple ranks is what the name suggests, simple. Here's some stuff you might want to know:


- You can change your rank by using !rankmenu.

- Players with special flag (sm_inf_customrank) can use sm_customrank to set their own rank with own colors.

- You can change the map's reward amount with sm_setmapreward <map name (optional)> <amount>. Without map name, set current map's reward.

- The default map reward cvar does not apply to bonuses. You must set the reward for bonuses yourself with sm_setmapreward.

- You can give players points with !givesimplepoints <target (optional)> <amount>.

- I urge you to configure the ranks, their names and colors, style rewards, etc. The configuration out of the box is bad and will most likely not fit your mapcycle/styles you host.